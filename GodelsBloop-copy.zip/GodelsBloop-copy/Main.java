import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.Desktop;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class Main {

    public static void main(String[] args) throws FileNotFoundException {
        JFileChooser fileChooser = new JFileChooser();

        // Configure file chooser to select source file
        fileChooser.setDialogTitle("Select Source File");
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

        int sourceFileResult = fileChooser.showOpenDialog(null);

        if (sourceFileResult == JFileChooser.APPROVE_OPTION) {
            File sourceFile = fileChooser.getSelectedFile();
            System.out.println("Source File chosen: " + sourceFile.getAbsolutePath());

            // Read and compile the code
            Parser parse = new Parser();
            List<Token> tokens = parse.Splitter(new File(sourceFile.getAbsolutePath()));
            Compile compiler = new Compile();
            String compiledCode = compiler.compile(tokens);
            String mainCode = compiler.MainBuilder();

            // Configure file chooser to select directory for output file
            fileChooser.setDialogTitle("Select Directory to Save output.c");
            fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

            int outputDirectoryResult = fileChooser.showSaveDialog(null);

            if (outputDirectoryResult == JFileChooser.APPROVE_OPTION) {
                File selectedDirectory = fileChooser.getSelectedFile();
                System.out.println("Output Directory chosen: " + selectedDirectory.getAbsolutePath());

                // Construct output file path
                String outputFilePath = selectedDirectory.getAbsolutePath() + File.separator + "output.c";

                // Write the compiled C code to the output file
                compiler.buildOutput(outputFilePath, mainCode, compiledCode);

                System.out.println("Successfully saved output.c to: " + outputFilePath);

                // Open the directory containing output.c using the default file manager
                try {
                    String directoryPath = selectedDirectory.getAbsolutePath();
                    openDirectoryInFileManager(directoryPath);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                System.out.println("No output directory selected.");
            }
        } else {
            System.out.println("No source file selected.");
        }
    }

    private static void openDirectoryInFileManager(String directoryPath) throws IOException {
        File directory = new File(directoryPath);
        if (directory.exists() && directory.isDirectory()) {
            Desktop.getDesktop().open(directory);
        } else {
            System.out.println("Directory does not exist: " + directoryPath);
        }
    }
}