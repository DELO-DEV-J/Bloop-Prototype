import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.io.*;

public class Compile 
{


    private String mainCall;
    // Compiler class responsible for generating C code from Bloop tokens
private Token savedToken;
    private ArrayList<Token> prototypeFuncs = new ArrayList<>();

    public String compile(List<Token> tokens) {
        StringBuilder cCode = new StringBuilder();
        int blockDepth = 0; // Track the depth of nested blocks
        boolean previousWasIf = false; // Flag to track if the previous token was an if statement

        int x = tokensearch(tokens,"TESTDECLERATION");

        for (Token token : tokens) {

            if (token.getType() == null) {
                // Log this to a proper logger instead of System.out
                System.out.println("Skipping token with null type: " + token);
                continue; // Skip tokens with null type
            }
            // Normalize token types
            String type = token.getType().toUpperCase();
            String name = token.getName().trim();
            String[] parameters = token.getParameters();
            String mainCall1= "";

            if(name.equals("RUN"))
            {
                mainCall = token.getType().trim();
                savedToken = token;
            }

            else if (type.equals("PROCEDUREDECLARATION")) {

                cCode.append("int ").append(name).append("(");
                if (parameters != null && parameters.length > 0) {
                    cCode.append("int ").append(String.join(", int ", parameters));
                }

                cCode.append(")");
                blockDepth++;
                prototypeFuncs.add(token);
            }
            else if(type.equals("TESTDECLERATION")){

                cCode.append("bool ").append(name).append("(");
                if (parameters != null && parameters.length > 0) {
                    cCode.append("int ").append(String.join(", int ", parameters));
                }

                cCode.append(")");
                blockDepth++;
                prototypeFuncs.add(token);
            }
            else if (type.equals("BEGIN")) {
                cCode.append("{\n");
                blockDepth++;
            } else if (type.equals("END")) {
                if (blockDepth > 0) {
                    cCode.append("}\n");
                    blockDepth--;
                } else {
                    System.out.println("Error: Unmatched END token.");
                    // Handle this error case as per your application's needs
                }
            } else if (type.equals("CONDITIONAL") && parameters != null) {
                for(int i = 0 ;i < parameters.length;i++)
                {
                    if(parameters[i].equals("OUTPUT")&&parameters[i+1].equals("⇐"))
                    {
                        parameters[i] = "return";
                        parameters[i+1] = " ";
                    }
                }

                cCode.append("if (");
                for (int i = 1; i < parameters.length; i++) { // Start from index 1 to skip "IF"
                    String work43 = " ";
                    work43 = parameters[i].trim().replaceAll("=","==");
                    if (i < parameters.length - 1) {
                        cCode.append(" ");
                    }
                    work43 = replaceLastOccurrence(work43);
                    cCode.append(work43);

                }

                cCode.append(") {\n");
                previousWasIf = true;
            } else if (type.startsWith("LOOP") && parameters != null) {
                String s = " ";
                for(int i = 0;i< parameters.length;i++)
                {
                    s += parameters[i] + " ";
                }
                cCode.append("for (int i = 0; i < ").append(s).append("; i++) ");
            } else if (type.equals("OUTPUT") && parameters != null) {
                cCode.append("printf(\"%d\\n\", ").append(parameters[0].trim()).append(");\n");
            } else if (type.equals("STATEMENT") && parameters != null && parameters.length > 0) {

                 for(int i = 0;i < parameters.length-1;i++)
                 {
                     if(parameters[i].equals("OUTPUT⇐") || parameters[i].equals("OUTPUT") && parameters[i+1].equals("⇐") )
                     {
                         parameters[i] = "return";
                         parameters[i+1] = " ";

                     }

                 }
                for (String para : parameters) {

                    cCode.append(para);

                }
                cCode.append("\n");
                if (previousWasIf) {

                    cCode.append("}\n");
                    previousWasIf = false;
                }
            } else if (name.equals("ABORT")) {
                // ABORT is handled by breaking out of the loop or conditional block
                if (blockDepth > 0) {
                    cCode.append("break;\n");
                }
                if (previousWasIf) {
                    cCode.append("}\n");
                    previousWasIf = false;
                } else {
                    System.out.println("Error: ABORT outside of block.");
                    // Handle this error case as per your application's needs
                }
            } else if (type.equals("QUIT")) {
                // QUIT is handled by closing the current block
                if (blockDepth > 0) {
                    cCode.append("return 0;");
                    blockDepth--;
                } else {
                    System.out.println("Error: Unmatched QUIT token.");
                    // Handle this error case as per your application's needs
                }
                if (previousWasIf) {
                    cCode.append("}\n");
                    previousWasIf = false;
                }
            }
            else {
                System.out.println("Unknown token type: " + type);
                System.out.println(token);
                // Handle unknown token types if necessary
            }

        }

        // Close any remaining open blocks at the end of the compilation


        return cCodeCleaner(cCode.toString());
    }
public boolean contains(String[] parameters,String target)
    {
       for(String search : parameters)
       {
    search = search.replaceAll(";"," ");
          if(search.trim().equals(target)){
              return true;
          }
       }
       return false;
    }
    public boolean contains(char[] parameters)
    {
        for(char search : parameters)
        {

            if(search == '('){
                return true;
            }
        }
        return false;
    }
    public int search(String[] parameters,String target)
    {
        for(int i = 0;i < parameters.length;i++)
        {

            String search = parameters[i].trim().replaceAll(";"," ");
            if(search.equals(target)){
                return i;
            }
        }
        return-1;
    }
    public int counter(String list)
    {
        int count = 0;
        for(int i = 0;i < list.length();i++)
        {
            char[] chars = list.toCharArray();
            for(int z = 0;z< chars.length;z++)
            {
                if(chars[z] == ',')
                {
                    count++;
                }
            }
        }
        return count;
    }
    public boolean reverseSearch(List<Token> token,Token currentToken)
    {
        for(int i = tokensearch(token,currentToken.getType());i>= 0;i--)
        {
            String type = token.get(i).getType();
            if(type.equals("PROCEDUREDECLARATION"))
            {
                return false;
            }
            else if(type.equals("TESTDECLERATION"))
            {
                return true;
            }

        }
        return false;
    }

    public  String replaceLastOccurrence(String original) {
        int x = counter(original);
        char[] chars = original.toCharArray();
        if(contains(original.toCharArray())) {
            original = original.replaceFirst(",", "&");
            original = original.replaceAll(",", " ");
            original = original.replaceAll("&", ",");

        }
       else if(counter(original) > 1) {
            original = original.replaceFirst(","," ");
        }

        return original;
    }
    public int tokensearch(List<Token> list,String target)
    {
        for(int i = 0;i < list.size();i++)
        {

            String search = list.get(i).getType().trim().replaceAll(";"," ");
            if(search.equals(target)){
                return i;
            }
        }
        return-1;
    }
    public String cCodeCleaner(String clean)
    {
        clean = clean.replaceAll("⇐","=");
        clean = clean.replaceAll(";","%");
        clean = clean.replaceAll("YES","true");
        clean = clean.replaceAll("NO","false");
        clean = clean.replaceAll("%",";");

        return clean;
    }
    public String protoFuncMaker()
    {
        ArrayList<Token> proto = prototypeFuncs;
        StringBuilder protomaker = new StringBuilder();

        for(Token token : proto)

        {

            if(token.getType().equals("PROCEDUREDECLARATION")) {
                protomaker.append("int " + token.getName() + paraModder(token.getParameters()) + ";" + "\n");
            }
            else {
                protomaker.append("bool " + token.getName() + paraModder(token.getParameters()) + ";" + "\n");
            }
        }
        return protomaker.toString().replaceAll("\\[","(").replaceAll("\\]",")");
    }
public String paraModder(String[] input)
{
    for(int i = 0;i < input.length;i++)
    {
        input[i] ="int " + input[i];

    }
    return Arrays.toString(input);
}
    public String MainBuilder()
    {
        StringBuilder newMain = new StringBuilder();
        newMain.append("/* main.c */" + "\n"+ "#include <stdio.h>\n"+"#include <stdbool.h>\n");
        newMain.append("int CELL[100] = {0}; \n");
        newMain.append("int OUTPUT = -1;\n");
        newMain.append(protoFuncMaker()+"\n");
        newMain.append("int main(int argc, char *argv[]) {\n");
        newMain.append("OUTPUT = " + mainCall + Arrays.toString(savedToken.getParameters()).replaceAll("\\[","(").replaceAll("\\]",")") + ";\n");
        newMain.append("printf(\"Output: %d\\n\", OUTPUT);\n");
        newMain.append("return OUTPUT;\n");
        newMain.append("}\n");
        return newMain.toString();
    }
    public void buildOutput(String filePath, String output1, String output2) {
        try {
            FileWriter writer = new FileWriter(filePath);
            writer.write(output1);
            writer.write(output2);
            writer.close();
            System.out.println("Successfully wrote to the file: " + filePath);
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

}



