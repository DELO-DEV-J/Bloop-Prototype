import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Parser 
{
    private ArrayList<Token> tokenArrayList;
    public ArrayList<Token> Splitter(File file) throws FileNotFoundException {
        Scanner scan = new Scanner(file);
        tokenArrayList = new ArrayList<Token>();
        ArrayList<Token> tomb = new ArrayList<>();
        while (scan.hasNextLine()) {
            String[] s = scan.nextLine().split("\n");
            tomb = Processor(s);
            Array(tomb);
        }
        return tokenArrayList;
    }

    public ArrayList<Token> Processor(String[] input) {
        String[] pre = input[0].split(" ");
        ArrayList<Token> tokenArrayList = new ArrayList<Token>();
        ArrayList<Integer> skippedIndexes = new ArrayList<Integer>();
        int count = 0;

        for (int i = 0; i < pre.length; i++) {
            if (contains(skippedIndexes, i)) {
                continue;
            } else if (pre[i].equals("RUN") && i + 1 < pre.length) {
                String name = pre[i];
                String[] type = pre[i + 1].replace(";", " ").split("\\[");
                String types = type[0];
                String parameters1 = pre[i+1].substring(pre[i+1].indexOf("[")+1,pre[i+1].indexOf("]"));
                String[] para2 = parameters1.split(",");

                Token RunCode = new Token(name, types,para2);
                tokenArrayList.add(RunCode);
            } else if (pre[i].equals("DEFINE") && i + 1 < pre.length && pre[i + 1].equals("PROCEDURE") ) {

                String name = pre[i + 2];
                name = name.replace("’’", " ");
                name = name.replace("‘’", " ");
                String parameters = pre[i + 3];
                parameters = parameters.replaceAll("\\[", " ");
                parameters = parameters.replaceAll("\\]", " ");
                parameters = parameters.replaceAll(":", " ");
                String[] para = parameters.trim().split(",");
                Token newProcedure = new Token(name.trim(),"PROCEDUREDECLARATION", para,para.length);
                tokenArrayList.add(newProcedure);
            }
            else if(pre[i].equals("DEFINE") && i + 1 < pre.length && pre[i + 1].equals("TEST"))
            {
                String name = pre[i+2];
                name = name.replace("’’", " ");
                name = name.replace("‘’", " ");
                String parameters = pre[i + 3];
                parameters = parameters.replaceAll("\\[", " ");
                parameters = parameters.replaceAll("\\]", " ");
                parameters = parameters.replaceAll(":", " ");
                String[] para = parameters.trim().split(",");
                Token newTEST = new Token(name.trim(),"TESTDECLERATION",para,true);
                tokenArrayList.add(newTEST);
            }
            else if (pre[i].trim().equals("BLOCK") && i + 2 < pre.length) {

                String name1 = pre[i + 1];
                name1 = name1.replaceAll(":", " ");
                name1 = "B" + name1;
                String type1 = pre[i + 2];
                Token block = new Token(name1, type1);
                tokenArrayList.add(block);

            } else if (pre[i].trim().equals("IF")) {
                int ind = indexsOf(pre, i);
                int sInd1 = find(pre, "THEN:");
                int fInd1 = find(pre, ";");


                for (int j = i; j < pre.length; j++) {
                    if (j < ind) {
                        skippedIndexes.add(j);
                    }
                }
                String[] params = sectionOf(i, ind, pre);
                String name = pre[i];
                Token ifState = new Token(name,"CONDITIONAL", params);
                tokenArrayList.add(ifState);
            } else if (pre[i].trim().equals("QUIT") && i + 2 < pre.length) {
                if (pre[i + 1].trim().equals("BLOCK")) {
                    String name3 = pre[i + 1] + pre[i + 2].trim();
                    name3 = name3.replaceAll(";", " ");
                    String type1 = pre[i].trim();
                    Token token2 = new Token(name3, type1);
                    tokenArrayList.add(token2);
                }

            } else if (pre[i].trim().equals("LOOP") && i + 3 < pre.length) {
                int s1 = find(pre, "MOST");
                int s2 = find(pre, "TIMES:");
                String[] params = sectionOf(s1+1, s2-1, pre);
                count++;
                String name = pre[i] + count;
                Token token3 = new Token(name,"LOOP", params);
                tokenArrayList.add(token3);
            } else if (pre[i].trim().equals("ABORT")) {
                String pret = pre[i + 1].trim() + pre[i + 2].trim();
                String typ = "ABORT";
                Token to1 = new Token(typ, pret);
                tokenArrayList.add(to1);
            } else if (pre[i].trim().equals("OUTPUT") || isCell(pre[i].trim())) {
                int finish = find(pre, i, ";");
                String[] list = sectionOf(i, finish, pre);
                for (String s : list) {
                    int x = specFind(pre, i, s);
                    skippedIndexes.add(x);
                }
                Token token5 = new Token("STATEMENT","STATEMENT", list);
                tokenArrayList.add(token5);
            }
        }

        return tokenArrayList;
    }

    public String[] sectionOf(int x, int r, String[] ls) {
        ArrayList<String> list1 = new ArrayList<String>();
        for (int i = x; i < r + 1; i++) {
            list1.add(ls[i]);
        }
        return toArrays(list1);
    }

    public int find(String[] list, int start, String target) {
        int y = -1;
        for (int i = start; i < list.length; i++) {
            if (list[i].contains(target)) {
                y = i;
                return y;
            }
        }
        return y;
    }

    public int find(String[] list, String target) {
        int y = -1;
        for (int i = 0; i < list.length; i++) {
            if (list[i].equals(target)) {
                y = i;
                return y;
            }
        }
        return y;
    }

    public int specFind(String[] list, int r, String target) {
        int y = -1;
        for (int i = r; i < list.length; i++) {
            if (list[i].equals(target)) {
                y = i;
                return y;
            }
        }
        return y;
    }

    public static boolean isNumber(String str) {
        return str.matches("-?\\d+(\\.\\d+)?");  //match a number with optional '-' and decimal.
    }

    public boolean isCell(String str) {
        char[] chars = str.toCharArray();
        if (chars.length > 4) {
            return chars[0] == 'C' && chars[1] == 'E' && chars[2] == 'L' && chars[3] == 'L';
        }
        return false;
    }

    public int indexsOf(String[] list, int i) {
       int z =  counter(list,i+1);
        for (int x = i + 1; x < list.length; x++) {
            if(z > 1)
            {
                z--;
            }
            else if (list[x].trim().contains(",")) {

                return x;
            }

        }
        return -1;
    }

public int counter(String[] list,int x)
{
    int count = 0;
    for(int i = x;i < list.length;i++)
    {
        char[] chars = list[i].toCharArray();
        for(int z = 0;z< chars.length;z++)
        {
            if(chars[z] == ',')
            {
                count++;
            }
        }
    }
    return count;
}
    public boolean contains(ArrayList<Integer> list, int x) {
        return list.contains(x);


    }


    public String[] toArrays(ArrayList<String> list) {
        String[] retlist = new String[list.size()];

        for (int i = 0; i < list.size(); i++) {
            retlist[i] = list.get(i);
        }
        return retlist;
    }

    public void Array(ArrayList<Token> tokenList) {

int i =0;
        for (Token token : tokenList) {
            System.out.println();
            i++;
tokenArrayList.add(token);
        }
    }


}




