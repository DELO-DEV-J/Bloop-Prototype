import java.util.Arrays;

public class Token {
    private String name;
    private String type;

    private String decStatement;

    private String[] parameters;

    private int num;

    private boolean isTEST;
  private String beginOrEnd;
    public Token(String name,String type, String[] parameters,int num)
    {
 this.name = name;
 this.parameters = parameters;
 this.type = type;
 this.num = num;
    }
    public Token(String name,String type, String[] parameters,boolean isTEST)
    {
        this.name = name;
        this.parameters = parameters;
        this.type = type;
        this.isTEST = isTEST;
    }
    public Token(String name,String type, String[] parameters)
    {
        this.name = name;
        this.parameters = parameters;
        this.type = type;

    }
    public Token(String name,String type)
    {
this.name = name;
this.type = type;
    }

    public Token(String name,String type,String beginOrEnd)
    {
        this.name = name;
        this.type = type;
        this.beginOrEnd = beginOrEnd;
    }

    public String toString()
    {

       return this.name + ","+  this.type + "," + Arrays.toString(this.parameters) ;
    }

    public String getName()
    {
        return name;
    }

    public String getType()
    {
        return type;
    }

    public String getDecStatement()
    {
        return decStatement;
    }

    public String getBeginOrEnd()
    {
        return beginOrEnd;
    }

    public String[] getParameters()
    {
        return parameters;
    }

    public int getNum ()
    {
return num;
}
}